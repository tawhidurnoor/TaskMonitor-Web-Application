

<?php $__env->startSection('head'); ?>
<title> Screenshots | Time Tracker Solution</title>
<?php $__env->stopSection(); ?>

<!-- Data Table CSS
============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets_backend/css/jquery.dataTables.min.css')); ?>">


<?php $__env->startSection('body'); ?>

<!-- Breadcomb area Start-->
<div class="breadcomb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="breadcomb-list">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="breadcomb-wp">
                                <div class="breadcomb-icon">
                                    <i class="fa fa-laptop" aria-hidden="true"></i>
                                </div>
                                <div class="breadcomb-ctn">
                                    <h2>Screenshot</h2>
                                    <p>
                                        
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-3">
                            <div class="breadcomb-report">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcomb area End-->
<!-- Data Table area Start-->
<div class="data-table-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="data-table-list">
                    <!--
                        <div class="basic-tb-hd">
                        <h2>Basic Example</h2>
                        <p>It's just that simple. Turn your simple table into a sophisticated data table and offer your users a nice experience and great features without any effort.</p>
                    </div>
                    -->

                    <?php echo $__env->make('backend.layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <br>

                    
                    <?php $__currentLoopData = $screenshots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screenshot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <div class="col">
                                <img src="<?php echo e(asset('captured/'.$screenshot->image)); ?>" alt="" srcset="">
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Data Table area End-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Data Table JS
		============================================ -->
<script src="<?php echo e(asset('assets_backend/js/data-table/jquery.dataTables.min.js')); ?>">
</script>
<script src="<?php echo e(asset('assets_backend/js/data-table/data-table-act.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.full.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Tawhidur Nood Badhan\Time_Tracker_Solution--Web-Module\resources\views/backend/project/screenshot.blade.php ENDPATH**/ ?>