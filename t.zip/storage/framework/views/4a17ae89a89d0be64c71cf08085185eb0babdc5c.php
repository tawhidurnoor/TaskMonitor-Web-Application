<?php if($errors->any()): ?>
<div class="alert alert-danger alert-dismissible alert-mg-b-0" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">
            <i class="notika-icon notika-close"></i>
        </span>
    </button>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p><?php echo e($error); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>

<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible alert-mg-b-0" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">
            <i class="notika-icon notika-close"></i>
        </span>
    </button>
    <p>
        <?php echo e(Session::get('success')); ?>

    </p>
</div>
<?php endif; ?><?php /**PATH E:\Tawhidur Nood Badhan\laravel_user_role_and_permission_using_spatie\resources\views/layouts/partials/messages.blade.php ENDPATH**/ ?>