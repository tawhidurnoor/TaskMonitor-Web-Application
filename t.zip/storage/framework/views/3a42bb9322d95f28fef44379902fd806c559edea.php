<!doctype html>
<html class="no-js" lang="">

<head>
    <?php echo $__env->yieldContent('head'); ?>

    <?php echo $__env->make('backend.layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <?php echo $__env->make('backend.layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('backend.layouts.partials.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main Body -->
    <?php echo $__env->yieldContent('body'); ?>
    <!-- Main Body Ends-->

    <?php echo $__env->make('backend.layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('backend.layouts.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('scripts'); ?>

</body>

</html><?php /**PATH E:\Tawhidur Nood Badhan\Time_Tracker_Solution--Web-Module\resources\views/backend/layouts/full/mainlayout.blade.php ENDPATH**/ ?>