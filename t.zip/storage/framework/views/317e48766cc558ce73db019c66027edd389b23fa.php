<!-- Vendor JS Files -->
<script src="assets_landing_page/assets/vendor/aos/aos.js"></script>
<script src="assets_landing_page/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets_landing_page/assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets_landing_page/assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets_landing_page/assets/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="assets_landing_page/assets/js/main.js"></script><?php /**PATH E:\Tawhidur Nood Badhan\Time_Tracker_Solution--Web-Module\resources\views/frontend/layouts/partial/scripts.blade.php ENDPATH**/ ?>