

<?php $__env->startSection('head'); ?>
<title> <?php echo e($staff->name); ?> - Time Tracker History  | Time Tracker Solution</title>
<?php $__env->stopSection(); ?>

<!-- Data Table CSS
============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets_backend/css/jquery.dataTables.min.css')); ?>">


<?php $__env->startSection('body'); ?>

<!-- Breadcomb area Start-->
<div class="breadcomb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="breadcomb-list">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="breadcomb-wp">
                                <div class="breadcomb-icon">
                                    <i class="fa fa-laptop" aria-hidden="true"></i>
                                </div>
                                <div class="breadcomb-ctn">
                                    <h2><?php echo e($staff->name); ?>'s Time Tracker History</h2>
                                    <p>
                                        <?php echo e($staff->name); ?>'s Time Tracker History for the project <i><?php echo e($project->title); ?></i>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-3">
                            <div class="breadcomb-report">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcomb area End-->
<!-- Data Table area Start-->
<div class="data-table-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="data-table-list">
                    <!--
                        <div class="basic-tb-hd">
                        <h2>Basic Example</h2>
                        <p>It's just that simple. Turn your simple table into a sophisticated data table and offer your users a nice experience and great features without any effort.</p>
                    </div>
                    -->

                    <?php echo $__env->make('backend.layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <br>

                    <div class="table-responsive">
                        <table id="data-table-basic" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Task Title</th>
                                    <th>Start</th>
                                    <th>End</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $timeTrackers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeTracker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php echo e($loop->index+1); ?> </td>
                                    <td> <?php echo e($timeTracker->task_title); ?> </td>
                                    <td>
                                        <?php echo e($timeTracker->start); ?>

                                    </td>
                                    <td>
                                        <?php if(isset($timeTracker->end)): ?>
                                            <?php echo e($timeTracker->end); ?>

                                        <?php else: ?>
                                            Running
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-list">
                                            <a href="<?php echo e(route('project.screenShot', $timeTracker->id)); ?>"
                                                class="btn btn-info waves-effect">
                                                Screen Shots
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Data Table area End-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Data Table JS
		============================================ -->
<script src="<?php echo e(asset('assets_backend/js/data-table/jquery.dataTables.min.js')); ?>">
</script>
<script src="<?php echo e(asset('assets_backend/js/data-table/data-table-act.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.full.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Tawhidur Nood Badhan\Time_Tracker_Solution--Web-Module\resources\views/backend/project/timeTracker.blade.php ENDPATH**/ ?>