<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GhostEmployee extends Model
{
    //
}
