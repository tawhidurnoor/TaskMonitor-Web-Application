<?php

namespace App\Http\Controllers\Backend;

use App\GhostEmployee;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class GhostEmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\GhostEmployee  $ghostEmployee
     * @return \Illuminate\Http\Response
     */
    public function show(GhostEmployee $ghostEmployee)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\GhostEmployee  $ghostEmployee
     * @return \Illuminate\Http\Response
     */
    public function edit(GhostEmployee $ghostEmployee)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\GhostEmployee  $ghostEmployee
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, GhostEmployee $ghostEmployee)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\GhostEmployee  $ghostEmployee
     * @return \Illuminate\Http\Response
     */
    public function destroy(GhostEmployee $ghostEmployee)
    {
        //
    }
}
